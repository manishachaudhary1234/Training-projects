function onsubmitClick(){
  alert("Name="+document.getElementById('name').value+"Email="+document.getElementById('email').value+" Phone="+document.getElementById('phone').value+" Web="+document.getElementById('web').value+
  " DOB="+document.getElementById('date').value)
}
