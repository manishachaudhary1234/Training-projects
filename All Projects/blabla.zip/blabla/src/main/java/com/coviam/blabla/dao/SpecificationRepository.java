package com.coviam.blabla.dao;

import org.springframework.data.repository.CrudRepository;

import com.coviam.blabla.entity.Specification;

public interface SpecificationRepository extends CrudRepository<Specification, Integer>{

}
